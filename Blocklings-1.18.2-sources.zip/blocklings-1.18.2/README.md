# Blocklings 1.18.2

Portage du mod Forge [Blocklings](https://www.curseforge.com/minecraft/mc-mods/blocklings) de WillR27 vers Minecraft **1.18.2**.

Les petites créatures en forme de bloc apparaissent dans l'Overworld. On peut les apprivoiser, les faire monter de niveau et leur confier des tâches : combat, minage, bûcheronnage, agriculture, dépôts dans les coffres.

Cette version **7.1.0** reprend le code GPL-3.0 de la branche `1.16` (7.0.0.5). L'archive `7.0.0_b4.1` pour 1.16.5 est une bêta un peu plus ancienne du même mod. Le droit d'auteur reste celui de WillR27. La licence de ce port est la GNU GPL v3.0 (voir `LICENSE`).

## Prérequis

- Java 17
- Minecraft 1.18.2
- Forge `40.2.21` ou une version `40.x` plus récente

## Installer

Le jar jouable est `dist/Blocklings-7.1.0-1.18.2.jar` (Forge 1.18.2, déjà réobfusqué).

Dans le dossier `mods` de l'instance, retire l'ancien fichier `Blocklings 7.0.0_b4.1 - 1.16.5.jar`. Un seul jar `blocklings` doit rester, sinon Forge charge encore la version 1.16.5 (`7.0.0.4`) et plante sur `net.minecraft.entity.EntityType`.

## Compiler

```bash
./gradlew build
```

Le jar à placer dans le dossier `mods` est produit par la tâche `reobfJar`, dans `build/libs`.

## Lancer le client de développement

```bash
./gradlew runClient
```

Le serveur de développement se lance avec `./gradlew runServer`.

## Limites de ce port

L'interopérabilité avec Tinkers' Construct est désactivée. Blocklings se charge à côté de Tinkers' Construct, mais les outils TiC ne sont plus reconnus comme pioches, haches ou houes.

Les apparitions naturelles passent par un biome modifier Forge : `src/main/resources/data/blocklings/forge/biome_modifier/blockling_spawns.json`.
