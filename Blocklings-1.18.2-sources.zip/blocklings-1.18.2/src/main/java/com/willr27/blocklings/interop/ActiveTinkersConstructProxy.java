package com.willr27.blocklings.interop;

/**
 * Optional Tinkers' Construct hook.
 * The 1.18.2 port keeps the proxy so the mod still loads beside Tinkers' Construct,
 * but tool-specific behaviour falls back to the no-op base until that API is wired again.
 */
public class ActiveTinkersConstructProxy extends TinkersConstructProxy
{
}
