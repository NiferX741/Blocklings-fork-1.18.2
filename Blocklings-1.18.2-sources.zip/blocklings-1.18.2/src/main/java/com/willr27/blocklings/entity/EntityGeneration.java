package com.willr27.blocklings.entity;

import com.willr27.blocklings.entity.blockling.BlocklingEntity;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.SpawnPlacements;
import net.minecraft.world.level.levelgen.Heightmap;

/**
 * Handles natural spawning for blocklings.
 * Spawn entries themselves live in a biome modifier so they survive the 1.18 worldgen changes.
 */
public class EntityGeneration
{
    /**
     * Custom entity classification for blocklings.
     */
    public static final MobCategory BLOCKLING = MobCategory.create("BLOCKLING", "blockling", 64, true, false, 192);

    /**
     * Registers entities to be spawned in the world.
     */
    public static void init()
    {
        SpawnPlacements.register(BlocklingsEntityTypes.BLOCKLING.get(), SpawnPlacements.Type.ON_GROUND, Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, BlocklingEntity::checkBlocklingSpawnRules);
    }
}
