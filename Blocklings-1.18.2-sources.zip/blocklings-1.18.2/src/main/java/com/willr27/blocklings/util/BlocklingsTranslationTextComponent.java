package com.willr27.blocklings.util;

import net.minecraft.network.chat.TranslatableComponent;

public class BlocklingsTranslationTextComponent extends TranslatableComponent
{
    public BlocklingsTranslationTextComponent(String key)
    {
        super("blocklings." + key);
    }

    public BlocklingsTranslationTextComponent(String key, Object... objects)
    {
        super("blocklings." + key, objects);
    }
}
